import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;
const DB_PATH = path.join(process.cwd(), 'database.json');

app.use(express.json());

// Initialize default database state if file does not exist
function getInitialDbState() {
  const todayStr = new Date().toISOString().split('T')[0]; // "2026-06-26"
  
  // Set deadlines relative to the local time 2026-06-26
  const deadline1 = '2026-06-26T18:00:00.000Z'; // ML Report (due in ~16 hours from morning)
  const deadline2 = '2026-06-27T10:00:00.000Z'; // Power bill (due tomorrow morning)
  const deadline3 = '2026-06-28T17:00:00.000Z'; // Pitch Deck (due in 2 days)
  const deadline4 = '2026-06-30T12:00:00.000Z'; // Renew license (due in 4 days)

  return {
    tasks: [
      {
        id: 'task-1',
        title: 'Machine Learning Final Report',
        description: 'Submit final report PDF and GitHub code link for CS 482. Must contain validation curves.',
        deadline: deadline1,
        priority: 'high',
        estimatedDuration: 180,
        status: 'in_progress',
        category: 'Study',
        bufferMinutes: 30,
        subtasks: [
          { id: 'sub-1-1', title: 'Format LaTeX document', completed: true },
          { id: 'sub-1-2', title: 'Run final model evaluations', completed: false, estimatedMinutes: 45 },
          { id: 'sub-1-3', title: 'Record 2-minute video presentation', completed: false, estimatedMinutes: 60 },
          { id: 'sub-1-4', title: 'Upload ZIP and submit on LMS portal', completed: false, estimatedMinutes: 30 }
        ],
        scheduledStart: '2026-06-26T10:00:00.000Z',
        aiPrioritizationScore: 96,
        aiActionRecommendation: '🚨 CRITICAL DEADLINE: This paper is due TODAY. Prioritize Model Evaluations and Video Presentation first. Turn off your notifications from 10 AM to 1 PM. Let us execute this!',
        panicLevel: 'panic'
      },
      {
        id: 'task-2',
        title: 'Pay Monthly Electricity Bill',
        description: 'Utility portal payment of $142.50 to avoid a late fee. Takes only 5 minutes.',
        deadline: deadline2,
        priority: 'medium',
        estimatedDuration: 15,
        status: 'todo',
        category: 'Bills',
        bufferMinutes: 10,
        subtasks: [
          { id: 'sub-2-1', title: 'Log into power utility portal', completed: false },
          { id: 'sub-2-2', title: 'Submit digital payment and save receipt', completed: false }
        ],
        scheduledStart: '2026-06-26T14:00:00.000Z',
        aiPrioritizationScore: 68,
        aiActionRecommendation: '⚡ QUICK WIN: Pay this during your afternoon break at 2:00 PM. It is a 5-minute task that will clear clutter off your brain.',
        panicLevel: 'warning'
      },
      {
        id: 'task-3',
        title: 'Polish Seed Round Pitch Deck',
        description: 'Refine slides for the investor meeting. Must polish financial forecast and GTM slides.',
        deadline: deadline3,
        priority: 'high',
        estimatedDuration: 240,
        status: 'todo',
        category: 'Work',
        bufferMinutes: 60,
        subtasks: [
          { id: 'sub-3-1', title: 'Update cash burn and runway charts', completed: false, estimatedMinutes: 90 },
          { id: 'sub-3-2', title: 'Draft GTM slide partner pipeline list', completed: false, estimatedMinutes: 60 },
          { id: 'sub-3-3', title: 'Perform a self-recorded practice pitch', completed: false, estimatedMinutes: 90 }
        ],
        scheduledStart: null,
        aiPrioritizationScore: 82,
        aiActionRecommendation: '📈 STRATEGIC FOCUS: Important but not due today. Focus completely on your ML report today. Schedule a dedicated 4-hour slot tomorrow morning for this.',
        panicLevel: 'calm'
      },
      {
        id: 'task-4',
        title: 'Renew Driver\'s License',
        description: 'Go to DMV website to complete online license renewal before expiration.',
        deadline: deadline4,
        priority: 'low',
        estimatedDuration: 45,
        status: 'todo',
        category: 'Personal',
        bufferMinutes: 15,
        subtasks: [
          { id: 'sub-4-1', title: 'Take compliant digital photo', completed: false },
          { id: 'sub-4-2', title: 'Fill online DMV application', completed: false },
          { id: 'sub-4-3', title: 'Pay the processing fee', completed: false }
        ],
        scheduledStart: null,
        aiPrioritizationScore: 45,
        aiActionRecommendation: '🚗 COMFORT ZONE: Plenty of time left. Deal with this on Saturday morning when you have free cognitive bandwidth.',
        panicLevel: 'calm'
      }
    ],
    habits: [
      { id: 'habit-1', title: 'Morning Plan & Deadline Audit', frequency: 'daily', streak: 6, lastCompleted: todayStr },
      { id: 'habit-2', title: '15 Mins Focus/Deep Breathing Loop', frequency: 'daily', streak: 13, lastCompleted: todayStr }
    ],
    calendarEvents: [
      { id: 'event-1', title: 'ML Final Report Focus Session', start: '2026-06-26T10:00:00.000Z', end: '2026-06-26T13:00:00.000Z', associatedTaskId: 'task-1' },
      { id: 'event-2', title: 'Standup with Advisors', start: '2026-06-26T15:00:00.000Z', end: '2026-06-26T15:30:00.000Z', isLocked: true },
      { id: 'event-3', title: 'Quick Bill Payment', start: '2026-06-26T14:00:00.000Z', end: '2026-06-26T14:15:00.000Z', associatedTaskId: 'task-2' }
    ],
    settings: {
      focusBufferMinutes: 15,
      workStartTime: '09:00',
      workEndTime: '18:00',
      panicThresholdHours: 24
    }
  };
}

function loadDb(): any {
  try {
    if (fs.existsSync(DB_PATH)) {
      const data = fs.readFileSync(DB_PATH, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading database file, resetting to default', err);
  }
  const defaultState = getInitialDbState();
  saveDb(defaultState);
  return defaultState;
}

function saveDb(state: any): void {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(state, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing to database file', err);
  }
}

// Lazy Gemini API Client instantiation
let genAiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!genAiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error('GEMINI_API_KEY environment variable is missing.');
    }
    genAiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }
  return genAiClient;
}

// ---------------------------------------------
// Database Endpoints
// ---------------------------------------------

app.get('/api/db', (req, res) => {
  const db = loadDb();
  res.json(db);
});

app.post('/api/db', (req, res) => {
  saveDb(req.body);
  res.json({ status: 'success', data: req.body });
});

// ---------------------------------------------
// AI Endpoints
// ---------------------------------------------

// 1. Intelligent Task Prioritization
app.post('/api/ai/prioritize', async (req, res) => {
  try {
    const { tasks, settings } = req.body;
    if (!tasks || !Array.isArray(tasks)) {
      return res.status(400).json({ error: 'Tasks list is required.' });
    }

    let ai;
    try {
      ai = getGeminiClient();
    } catch (err: any) {
      // Graceful fallback for missing API Key
      console.warn('Gemini API key missing, providing smart local analysis.');
      const localAnalysis = tasks.map((t: any) => {
        const timeRemainingMs = new Date(t.deadline).getTime() - new Date().getTime();
        const hrsRemaining = timeRemainingMs / (1000 * 60 * 60);
        let score = 50;
        let recommendation = 'Keep working steadily!';

        if (t.priority === 'high') score += 20;
        if (t.priority === 'low') score -= 15;

        if (hrsRemaining < 24) {
          score += 25;
          recommendation = `🚨 URGENT: Due in ${Math.round(hrsRemaining)} hours! Clear other projects and do this next.`;
        } else if (hrsRemaining < 48) {
          score += 15;
          recommendation = `⚠️ ALERT: Due tomorrow. Plan a focus block for today.`;
        } else {
          recommendation = `📅 STABLE: Still has ${Math.round(hrsRemaining / 24)} days. Set aside time later.`;
        }

        return {
          id: t.id,
          aiPrioritizationScore: Math.min(100, Math.max(10, score)),
          aiActionRecommendation: recommendation,
        };
      });
      return res.json({ rankings: localAnalysis, isMock: true });
    }

    const todayStr = new Date().toISOString();
    const prompt = `
You are the AI brain for "The Last-Minute Life Saver" productivity companion.
Analyze the following user tasks with their descriptions, priorities, estimated durations, status, and deadlines.
The current time is ${todayStr}.

Tasks JSON:
${JSON.stringify(tasks, null, 2)}

Settings JSON:
${JSON.stringify(settings || {}, null, 2)}

Evaluate each task's absolute urgency and real-world importance. Calculate a Prioritization Score (0 to 100) where:
- 90-100: CRITICAL panic situation (e.g., due today/tomorrow, high impact/penalty if missed, complex tasks with little time left).
- 70-89: Warning stage (high priority or moderate urgency, needs to be done today or early tomorrow).
- 40-69: Moderate (stable but upcoming, medium/low priority, or simple 5-min tasks).
- 10-39: Comfortable (low priority, distant deadline, or tiny effort).

Generate a highly specific, tactical, stress-reducing 'aiActionRecommendation' (1-2 sentences) for EACH task. Tell the user *exactly* when or how to tackle it to avoid missing the deadline (e.g., "Do this first thing from 10 AM to 11:30 AM", "This is a quick 5-min win, pay it during lunch to get it out of the way"). Do not use generic advice.

Return the response STRICTLY as a JSON object of the following format:
{
  "rankings": [
    {
      "id": "task_id_here",
      "aiPrioritizationScore": 95,
      "aiActionRecommendation": "Specific saving advice..."
    }
  ]
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            rankings: {
              type: Type.ARRAY,
              description: 'The prioritized task list items.',
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  aiPrioritizationScore: { type: Type.INTEGER },
                  aiActionRecommendation: { type: Type.STRING }
                },
                required: ['id', 'aiPrioritizationScore', 'aiActionRecommendation']
              }
            }
          },
          required: ['rankings']
        }
      }
    });

    const data = JSON.parse(response.text || '{}');
    res.json(data);
  } catch (error: any) {
    console.error('Error in /api/ai/prioritize:', error);
    res.status(500).json({ error: error.message || 'Failed to prioritize tasks' });
  }
});

// 2. Autonomous Task Breakdown / Planner
app.post('/api/ai/breakdown', async (req, res) => {
  try {
    const { title, description, category } = req.body;
    if (!title) {
      return res.status(400).json({ error: 'Task title is required.' });
    }

    let ai;
    try {
      ai = getGeminiClient();
    } catch (err: any) {
      // Local fallback
      console.warn('Gemini API key missing, generating mock breakdown.');
      const subtasks = [
        { id: 'fallback-sub-1', title: 'Research & gather initial assets', completed: false, estimatedMinutes: 30 },
        { id: 'fallback-sub-2', title: 'Draft outline/main points', completed: false, estimatedMinutes: 45 },
        { id: 'fallback-sub-3', title: 'Build and review draft core sections', completed: false, estimatedMinutes: 60 },
        { id: 'fallback-sub-4', title: 'Refine and execute final submission', completed: false, estimatedMinutes: 15 }
      ];
      return res.json({ subtasks, isMock: true });
    }

    const prompt = `
You are the Autonomous Planner of "The Last-Minute Life Saver".
Break down the following daunting task into a sequence of exactly 3 to 5 realistic, bite-sized, actionable subtasks that are impossible to procrastinate on.
Task Title: "${title}"
Task Description: "${description || 'None'}"
Task Category: "${category || 'General'}"

For each subtask, generate:
1. A clear, action-oriented title (e.g. "Draft outline of Section 1" instead of "Drafting").
2. An estimated duration in minutes.

Return the response STRICTLY as a JSON object with this structure:
{
  "subtasks": [
    {
      "title": "Subtask title",
      "estimatedMinutes": 30
    }
  ]
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subtasks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  estimatedMinutes: { type: Type.INTEGER }
                },
                required: ['title', 'estimatedMinutes']
              }
            }
          },
          required: ['subtasks']
        }
      }
    });

    const data = JSON.parse(response.text || '{}');
    // Map with custom temporary ids for frontend
    const subtasksWithId = (data.subtasks || []).map((sub: any, idx: number) => ({
      id: `sub-${Date.now()}-${idx}`,
      title: sub.title,
      completed: false,
      estimatedMinutes: sub.estimatedMinutes || 20
    }));

    res.json({ subtasks: subtasksWithId });
  } catch (error: any) {
    console.error('Error in /api/ai/breakdown:', error);
    res.status(500).json({ error: error.message || 'Failed to breakdown task' });
  }
});

// 3. AI-Powered Smart Scheduling Assistant
app.post('/api/ai/suggest-schedule', async (req, res) => {
  try {
    const { tasks, settings, calendarEvents } = req.body;
    if (!tasks || !Array.isArray(tasks)) {
      return res.status(400).json({ error: 'Tasks list is required.' });
    }

    let ai;
    try {
      ai = getGeminiClient();
    } catch (err: any) {
      console.warn('Gemini API key missing, skipping smart calendar suggest.');
      return res.json({ scheduledEvents: [], isMock: true });
    }

    const todayStr = new Date().toISOString();
    const prompt = `
You are the Smart Scheduling Assistant for "The Last-Minute Life Saver".
Create an optimized daily calendar schedule mapping upcoming incomplete tasks to open slots.
The current local time is ${todayStr}.

User Settings:
- Work Start: ${settings?.workStartTime || '09:00'}
- Work End: ${settings?.workEndTime || '18:00'}
- Focus Buffer: ${settings?.focusBufferMinutes || 15} minutes between tasks

Active Tasks (Only schedule those with status "todo" or "in_progress" and deadlines upcoming):
${JSON.stringify(tasks.filter((t: any) => t.status !== 'completed'), null, 2)}

Existing Fixed Calendar Events (Do NOT overlap or schedule anything during these fixed slots):
${JSON.stringify(calendarEvents || [], null, 2)}

Formulate specific scheduled events for today and tomorrow. Align them with the user's work hours, task priority (highest priority tasks first), estimated durations, and include a buffer.
Only generate schedule events for tasks that need scheduling (i.e. currently incomplete).

Return the response STRICTLY as a JSON object with this structure:
{
  "scheduledEvents": [
    {
      "taskId": "task-id",
      "title": "Focus Session: Task Title",
      "start": "ISO_STRING_HERE",
      "end": "ISO_STRING_HERE"
    }
  ]
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            scheduledEvents: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  taskId: { type: Type.STRING },
                  title: { type: Type.STRING },
                  start: { type: Type.STRING, description: 'ISO format start time' },
                  end: { type: Type.STRING, description: 'ISO format end time' }
                },
                required: ['taskId', 'title', 'start', 'end']
              }
            }
          },
          required: ['scheduledEvents']
        }
      }
    });

    const data = JSON.parse(response.text || '{}');
    res.json(data);
  } catch (error: any) {
    console.error('Error in /api/ai/suggest-schedule:', error);
    res.status(500).json({ error: error.message || 'Failed to suggest schedule' });
  }
});

// 4. Urgency Counselor & Voice Coach Interactive Chat
app.post('/api/ai/chat', async (req, res) => {
  try {
    const { messages, dbState, voiceCommand } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages list is required.' });
    }

    let ai;
    try {
      ai = getGeminiClient();
    } catch (err: any) {
      console.warn('Gemini API key missing, fallback chat message.');
      return res.json({
        content: '🤖 The AI Life Saver Counselor is standing by, but requires a Gemini API Key to talk. Please add your GEMINI_API_KEY in the Secrets panel on the top right settings to activate me!'
      });
    }

    // Build context about current panic states, tasks, habits, calendar events, settings
    const activeTasks = dbState?.tasks || [];
    const now = new Date();
    
    let totalIncomplete = 0;
    let highPriorityCount = 0;
    let panicCount = 0;
    let warningCount = 0;
    
    const taskStatusSummary = activeTasks.map((t: any) => {
      const deadlineDate = new Date(t.deadline);
      const hrsLeft = (deadlineDate.getTime() - now.getTime()) / (1000 * 60 * 60);
      let urgency = 'calm';
      
      if (t.status !== 'completed') {
        totalIncomplete++;
        if (t.priority === 'high') highPriorityCount++;
        
        if (hrsLeft > 0) {
          if (hrsLeft <= 12) {
            urgency = 'CRITICAL PANIC';
            panicCount++;
          } else if (hrsLeft <= 24) {
            urgency = 'HIGH WARNING';
            warningCount++;
          }
        } else {
          urgency = 'MISSED DEADLINE!';
        }
      }
      
      return `- "${t.title}" (${t.category}) | Priority: ${t.priority} | Status: ${t.status} | Due in: ${hrsLeft > 0 ? hrsLeft.toFixed(1) + ' hrs' : 'Expired'} | Urgency: ${urgency}`;
    }).join('\n');

    const contextPrompt = `
You are the "Life Saver Urgency Counselor", a proactive, calm, empathetic but highly disciplined productivity savior.
Your mission is to help students, professionals, and founders who are overwhelmed, panicking about deadlines, or procrastinating.

Core Personality:
- Calm, assuring, non-judgmental, but extremely practical.
- Focuses on the next immediate microscopic step (reducing resistance).
- Uses stress-relief metaphors (e.g. box breathing, calming mental anchors).
- Celebrates streaks and progress with high energy!

Current User Workspace Summary:
- Incomplete Tasks: ${totalIncomplete}
- High Priority Tasks: ${highPriorityCount}
- Tasks in CRITICAL Panic (<12h remaining): ${panicCount}
- Tasks in Warning (<24h remaining): ${warningCount}

Active Tasks Workspace:
${taskStatusSummary || 'No tasks listed yet.'}

Current Local Time is: ${now.toString()}

If the user is freaking out, guide them through a 30-second breathing count, then force them to choose the smallest possible task to complete in 5 minutes.
Keep your answer relatively concise (100-200 words) so they spend more time working and less time chatting.
`;

    // Map message history
    const geminiContents = messages.map((m: any) => {
      return {
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }]
      };
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: geminiContents,
      config: {
        systemInstruction: contextPrompt,
        temperature: 0.7,
      }
    });

    res.json({ content: response.text || 'No response.' });
  } catch (error: any) {
    console.error('Error in /api/ai/chat:', error);
    res.status(500).json({ error: error.message || 'Chat assistance failed' });
  }
});

async function startServer() {
  // Serve static build or setup Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`The Last-Minute Life Saver server is running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
