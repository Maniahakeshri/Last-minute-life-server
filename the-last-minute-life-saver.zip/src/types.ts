export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
  estimatedMinutes?: number;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  deadline: string; // ISO string
  priority: 'high' | 'medium' | 'low';
  estimatedDuration: number; // in minutes
  status: 'todo' | 'in_progress' | 'completed' | 'missed';
  category: string; // 'Work' | 'Study' | 'Bills' | 'Personal' | 'Other'
  bufferMinutes: number; // buffer cushion time
  subtasks: SubTask[];
  scheduledStart: string | null; // ISO string, if scheduled
  aiPrioritizationScore: number; // 0-100 score of urgency/importance
  aiActionRecommendation?: string; // custom instructions from AI on how to tackle this
  panicLevel: 'calm' | 'warning' | 'panic'; // dynamic urgency calculation
}

export interface Habit {
  id: string;
  title: string;
  frequency: 'daily' | 'weekly';
  streak: number;
  lastCompleted: string | null; // YYYY-MM-DD
}

export interface CalendarEvent {
  id: string;
  title: string;
  start: string; // ISO string
  end: string; // ISO string
  associatedTaskId?: string;
  isLocked?: boolean;
}

export interface AppSettings {
  focusBufferMinutes: number;
  workStartTime: string; // "HH:MM"
  workEndTime: string; // "HH:MM"
  panicThresholdHours: number; // hours remaining until task triggers visual panic
}

export interface DBState {
  tasks: Task[];
  habits: Habit[];
  calendarEvents: CalendarEvent[];
  settings: AppSettings;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string; // ISO string
}
