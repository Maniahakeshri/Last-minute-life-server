import { useState, useEffect } from 'react';
import { 
  ListTodo, Calendar, Flame, Sparkles, Settings, Save, AlertTriangle, 
  HelpCircle, Clock, Volume2, ShieldAlert, Loader2, Info
} from 'lucide-react';
import Header from './components/Header';
import TaskBoard from './components/TaskBoard';
import CalendarView from './components/CalendarView';
import HabitBoard from './components/HabitBoard';
import CoachChat from './components/CoachChat';
import { DBState, Task, Habit, CalendarEvent, AppSettings, ChatMessage } from './types';

export default function App() {
  const [dbState, setDbState] = useState<DBState>({
    tasks: [],
    habits: [],
    calendarEvents: [],
    settings: {
      focusBufferMinutes: 15,
      workStartTime: '09:00',
      workEndTime: '18:00',
      panicThresholdHours: 24
    }
  });

  const [activeTab, setActiveTab] = useState<'tasks' | 'calendar'>('tasks');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isPrioritizing, setIsPrioritizing] = useState(false);
  const [isScheduling, setIsScheduling] = useState(false);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // Load state from backend on mount
  useEffect(() => {
    async function init() {
      try {
        const res = await fetch('/api/db');
        if (res.ok) {
          const data = await res.json();
          setDbState(data);
        }
      } catch (err) {
        console.error('Error fetching database state:', err);
      } finally {
        setIsLoading(false);
      }
    }
    init();
  }, []);

  // Save state helper to push client changes back to server
  const saveState = async (updatedState: DBState) => {
    try {
      await fetch('/api/db', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedState)
      });
    } catch (err) {
      console.error('Failed to sync database to backend server:', err);
    }
  };

  // ---------------------------------------------
  // Task Handlers
  // ---------------------------------------------

  const handleAddTask = (taskInput: Omit<Task, 'id' | 'aiPrioritizationScore' | 'panicLevel'>) => {
    const newTask: Task = {
      ...taskInput,
      id: `task-${Date.now()}`,
      aiPrioritizationScore: 0,
      panicLevel: calculatePanicLevel(taskInput.deadline, taskInput.priority)
    };

    const updated = {
      ...dbState,
      tasks: [newTask, ...dbState.tasks]
    };
    setDbState(updated);
    saveState(updated);
  };

  const handleUpdateTask = (updatedTask: Task) => {
    // Recalculate panic level just in case deadline or priority changed
    const freshTask = {
      ...updatedTask,
      panicLevel: calculatePanicLevel(updatedTask.deadline, updatedTask.priority)
    };

    const updatedTasks = dbState.tasks.map(t => t.id === updatedTask.id ? freshTask : t);
    const updated = {
      ...dbState,
      tasks: updatedTasks
    };
    setDbState(updated);
    saveState(updated);
  };

  const handleDeleteTask = (id: string) => {
    const updatedTasks = dbState.tasks.filter(t => t.id !== id);
    // Also clean up any scheduled calendar events for this task
    const updatedEvents = dbState.calendarEvents.filter(e => e.associatedTaskId !== id);

    const updated = {
      ...dbState,
      tasks: updatedTasks,
      calendarEvents: updatedEvents
    };
    setDbState(updated);
    saveState(updated);
  };

  // Dynamic urgency calculator for task list items
  const calculatePanicLevel = (deadlineStr: string, priority: Task['priority']): Task['panicLevel'] => {
    const hoursRemaining = (new Date(deadlineStr).getTime() - Date.now()) / (1000 * 60 * 60);
    
    if (hoursRemaining <= 0) return 'panic';
    if (hoursRemaining <= 12) return 'panic';
    if (hoursRemaining <= dbState.settings.panicThresholdHours) return 'warning';
    return 'calm';
  };

  // Trigger server-side AI prioritzer
  const handlePrioritizeWithAI = async () => {
    try {
      setIsPrioritizing(true);
      const res = await fetch('/api/ai/prioritize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tasks: dbState.tasks,
          settings: dbState.settings
        })
      });

      if (!res.ok) throw new Error('Prioritization service returned error status');
      const data = await res.json();

      if (data.rankings && Array.isArray(data.rankings)) {
        const updatedTasks = dbState.tasks.map(task => {
          const match = data.rankings.find((r: any) => r.id === task.id);
          if (match) {
            return {
              ...task,
              aiPrioritizationScore: match.aiPrioritizationScore,
              aiActionRecommendation: match.aiActionRecommendation,
              panicLevel: calculatePanicLevel(task.deadline, task.priority)
            };
          }
          return task;
        });

        const updated = { ...dbState, tasks: updatedTasks };
        setDbState(updated);
        saveState(updated);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsPrioritizing(false);
    }
  };

  // ---------------------------------------------
  // Habit Handlers
  // ---------------------------------------------

  const handleAddHabit = (title: string, frequency: 'daily' | 'weekly') => {
    const newHabit: Habit = {
      id: `habit-${Date.now()}`,
      title,
      frequency,
      streak: 0,
      lastCompleted: null
    };

    const updated = {
      ...dbState,
      habits: [...dbState.habits, newHabit]
    };
    setDbState(updated);
    saveState(updated);
  };

  const handleToggleHabit = (id: string) => {
    const todayStr = new Date().toISOString().split('T')[0];
    const updatedHabits = dbState.habits.map(h => {
      if (h.id === id) {
        const completedToday = h.lastCompleted === todayStr;
        return {
          ...h,
          streak: completedToday ? Math.max(0, h.streak - 1) : h.streak + 1,
          lastCompleted: completedToday ? null : todayStr
        };
      }
      return h;
    });

    const updated = {
      ...dbState,
      habits: updatedHabits
    };
    setDbState(updated);
    saveState(updated);
  };

  const handleDeleteHabit = (id: string) => {
    const updatedHabits = dbState.habits.filter(h => h.id !== id);
    const updated = {
      ...dbState,
      habits: updatedHabits
    };
    setDbState(updated);
    saveState(updated);
  };

  // ---------------------------------------------
  // Calendar Event Handlers
  // ---------------------------------------------

  const handleAddEvent = (event: CalendarEvent) => {
    const updated = {
      ...dbState,
      calendarEvents: [...dbState.calendarEvents, event]
    };
    setDbState(updated);
    saveState(updated);
  };

  const handleClearAIEvent = (id: string) => {
    const updatedEvents = dbState.calendarEvents.filter(e => e.id !== id);
    const updated = {
      ...dbState,
      calendarEvents: updatedEvents
    };
    setDbState(updated);
    saveState(updated);
  };

  // AI Scheduling Suggestion Trigger
  const handleSuggestSchedule = async () => {
    try {
      setIsScheduling(true);
      const res = await fetch('/api/ai/suggest-schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tasks: dbState.tasks,
          settings: dbState.settings,
          calendarEvents: dbState.calendarEvents
        })
      });

      if (!res.ok) throw new Error('AI scheduler responded with an error.');
      const data = await res.json();

      if (data.scheduledEvents && Array.isArray(data.scheduledEvents)) {
        const newEvents: CalendarEvent[] = data.scheduledEvents.map((se: any) => ({
          id: `ai-event-${Date.now()}-${se.taskId}`,
          title: se.title,
          start: se.start,
          end: se.end,
          associatedTaskId: se.taskId
        }));

        // Merge schedule events, maintaining non-AI fixed meetings
        const fixedEvents = dbState.calendarEvents.filter(e => e.isLocked);
        const updated = {
          ...dbState,
          calendarEvents: [...fixedEvents, ...newEvents]
        };
        setDbState(updated);
        saveState(updated);

        // Switch to calendar tab so user sees their smart time blocks
        setActiveTab('calendar');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsScheduling(false);
    }
  };

  // ---------------------------------------------
  // Settings Handlers
  // ---------------------------------------------

  const handleSaveSettings = (settingsInput: AppSettings) => {
    const updated = {
      ...dbState,
      settings: settingsInput
    };
    setDbState(updated);
    saveState(updated);
    setShowSettings(false);
  };

  // ---------------------------------------------
  // AI Coach Chat integration
  // ---------------------------------------------

  const handleSendChatMessage = async (text: string) => {
    const userMsg: ChatMessage = {
      id: `chat-msg-${Date.now()}-user`,
      role: 'user',
      content: text,
      timestamp: new Date().toISOString()
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setIsChatLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages,
          dbState
        })
      });

      if (!res.ok) throw new Error('Chat Counselor service returned an error.');
      const data = await res.json();

      const assistantMsg: ChatMessage = {
        id: `chat-msg-${Date.now()}-assistant`,
        role: 'assistant',
        content: data.content || 'I apologize, I could not hear you over the sirens. Let us take a breath and try again.',
        timestamp: new Date().toISOString()
      };

      setMessages([...newMessages, assistantMsg]);
    } catch (err: any) {
      console.error(err);
      const errMsg: ChatMessage = {
        id: `chat-msg-${Date.now()}-assistant`,
        role: 'assistant',
        content: `Error: ${err.message || 'The neural path got congested.'}. Please verify your API Key is inserted in Settings > Secrets.`,
        timestamp: new Date().toISOString()
      };
      setMessages([...newMessages, errMsg]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleResetChat = () => {
    setMessages([]);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center text-zinc-300">
        <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
        <p className="mt-4 text-xs font-mono tracking-widest text-zinc-500 uppercase">Deploying Defenses...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#07070a] text-zinc-100 flex flex-col" id="app-root-container">
      {/* Sticky Urgency Indicator Header */}
      <Header tasks={dbState.tasks} settings={dbState.settings} />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main interactive area: Tasks control board or Calendar (Takes 3/4 layout) */}
        <div className="lg:col-span-3 flex flex-col gap-6" id="primary-layout-container">
          {/* Tab Navigation Controls */}
          <div className="flex items-center justify-between border-b border-zinc-900 pb-2">
            <div className="flex gap-1 bg-zinc-950 p-1 rounded-xl border border-zinc-900">
              <button
                onClick={() => setActiveTab('tasks')}
                className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition duration-200 cursor-pointer ${
                  activeTab === 'tasks'
                    ? 'bg-zinc-900 text-amber-400 border border-zinc-800'
                    : 'text-zinc-400 hover:text-white'
                }`}
                id="tab-tasks-trigger"
              >
                <ListTodo className="w-4 h-4" />
                Deadlines Board
              </button>

              <button
                onClick={() => setActiveTab('calendar')}
                className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition duration-200 cursor-pointer ${
                  activeTab === 'calendar'
                    ? 'bg-zinc-900 text-amber-400 border border-zinc-800'
                    : 'text-zinc-400 hover:text-white'
                }`}
                id="tab-calendar-trigger"
              >
                <Calendar className="w-4 h-4" />
                Smart Timeline Map
              </button>
            </div>

            {/* Quick config settings button */}
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 rounded-xl bg-zinc-950 border border-zinc-900 text-zinc-400 hover:text-white transition cursor-pointer"
              title="Cushion Settings"
              id="settings-trigger-btn"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>

          {/* Render Settings Overlay Drawer */}
          {showSettings && (
            <div className="p-5 rounded-2xl border border-zinc-800 bg-zinc-900/60 flex flex-col gap-4 animate-fadeIn" id="settings-panel">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Settings className="w-4 h-4 text-zinc-400" />
                  Configure Emergency Parameters
                </h3>
                <button 
                  onClick={() => setShowSettings(false)} 
                  className="text-xs text-zinc-500 hover:text-white"
                >
                  Close
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div className="flex flex-col gap-1.5">
                  <label className="text-zinc-400 font-semibold">Focus Buffer Between Slots (Mins)</label>
                  <input
                    type="number"
                    min="0"
                    max="60"
                    value={dbState.settings.focusBufferMinutes}
                    onChange={e => setDbState({
                      ...dbState,
                      settings: { ...dbState.settings, focusBufferMinutes: Number(e.target.value) }
                    })}
                    className="px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-white"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-zinc-400 font-semibold">Active Work Start Hour</label>
                  <input
                    type="text"
                    placeholder="09:00"
                    value={dbState.settings.workStartTime}
                    onChange={e => setDbState({
                      ...dbState,
                      settings: { ...dbState.settings, workStartTime: e.target.value }
                    })}
                    className="px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-white"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-zinc-400 font-semibold">Panic Trigger Threshold (Hrs)</label>
                  <input
                    type="number"
                    min="1"
                    max="72"
                    value={dbState.settings.panicThresholdHours}
                    onChange={e => setDbState({
                      ...dbState,
                      settings: { ...dbState.settings, panicThresholdHours: Number(e.target.value) }
                    })}
                    className="px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 mt-2">
                <button
                  onClick={() => handleSaveSettings(dbState.settings)}
                  className="px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold flex items-center gap-1 transition"
                >
                  <Save className="w-3.5 h-3.5" />
                  Save cushions
                </button>
              </div>
            </div>
          )}

          {/* Render Active Tab */}
          {activeTab === 'tasks' ? (
            <TaskBoard
              tasks={dbState.tasks}
              onAddTask={handleAddTask}
              onUpdateTask={handleUpdateTask}
              onDeleteTask={handleDeleteTask}
              onPrioritizeWithAI={handlePrioritizeWithAI}
              isPrioritizing={isPrioritizing}
            />
          ) : (
            <CalendarView
              tasks={dbState.tasks}
              events={dbState.calendarEvents}
              onAddEvent={handleAddEvent}
              onClearAIEvent={handleClearAIEvent}
              onSuggestSchedule={handleSuggestSchedule}
              isScheduling={isScheduling}
            />
          )}
        </div>

        {/* Sidebar Panel for habits checklist & interactive Counselor (Takes 1/4 layout) */}
        <div className="flex flex-col gap-6" id="sidebar-layout-container">
          {/* Habits streak counter */}
          <HabitBoard
            habits={dbState.habits}
            onAddHabit={handleAddHabit}
            onToggleHabit={handleToggleHabit}
            onDeleteHabit={handleDeleteHabit}
          />

          {/* Counseling Coach Assist panel */}
          <CoachChat
            dbState={dbState}
            messages={messages}
            onSendMessage={handleSendChatMessage}
            onResetChat={handleResetChat}
            isChatLoading={isChatLoading}
          />
        </div>
      </main>
    </div>
  );
}
