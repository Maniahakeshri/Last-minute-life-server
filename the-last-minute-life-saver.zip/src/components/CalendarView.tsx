import { useState } from 'react';
import { Calendar, Clock, Sparkles, Check, Trash, Lock, ShieldAlert, CheckSquare, Loader2 } from 'lucide-react';
import { Task, CalendarEvent } from '../types';

interface CalendarViewProps {
  tasks: Task[];
  events: CalendarEvent[];
  onAddEvent: (event: CalendarEvent) => void;
  onClearAIEvent: (id: string) => void;
  onSuggestSchedule: () => Promise<void>;
  isScheduling: boolean;
}

export default function CalendarView({
  tasks,
  events,
  onAddEvent,
  onClearAIEvent,
  onSuggestSchedule,
  isScheduling,
}: CalendarViewProps) {
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  // Generate hourly blocks from 08:00 to 19:00 for the current local day YYYY-MM-DD
  const hours = Array.from({ length: 12 }, (_, i) => i + 8); // 8 AM to 7 PM

  const formatHour = (h: number) => {
    const ampm = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 === 0 ? 12 : h % 12;
    return `${displayH}:00 ${ampm}`;
  };

  // Check if an event falls in a specific hour block
  const getEventsInHour = (hour: number) => {
    return events.filter(e => {
      const startHour = new Date(e.start).getHours();
      return startHour === hour;
    });
  };

  const getTaskForEvent = (eventId: string) => {
    const e = events.find(event => event.id === eventId);
    if (!e || !e.associatedTaskId) return null;
    return tasks.find(t => t.id === e.associatedTaskId);
  };

  return (
    <div className="flex flex-col gap-6" id="calendar-module">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-500" />
            AI Day Schedule Planner
          </h2>
          <p className="text-xs text-zinc-400">Fixed commitments overlayed with AI-allocated deep work blocks.</p>
        </div>

        <button
          onClick={onSuggestSchedule}
          disabled={isScheduling || tasks.filter(t => t.status !== 'completed').length === 0}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-600 to-red-600 hover:from-amber-500 hover:to-red-500 disabled:from-zinc-800 disabled:to-zinc-800 disabled:text-zinc-500 text-white font-semibold rounded-xl text-xs transition cursor-pointer shadow-md"
          id="ai-schedule-btn"
        >
          {isScheduling ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Generating Timeline...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              AI Smart Schedule
            </>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Timeline Grid */}
        <div className="lg:col-span-2 flex flex-col gap-2 bg-zinc-950/40 border border-zinc-800 rounded-2xl p-4 overflow-hidden">
          <div className="flex items-center justify-between border-b border-zinc-900 pb-3 mb-2">
            <span className="text-sm font-bold text-white">Daily Focus Agenda</span>
            <span className="text-[10px] font-mono uppercase bg-zinc-900 px-2 py-1 rounded text-zinc-400">
              Today: {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}
            </span>
          </div>

          <div className="flex flex-col gap-1 max-h-[500px] overflow-y-auto pr-1">
            {hours.map(hour => {
              const hourEvents = getEventsInHour(hour);
              return (
                <div key={hour} className="flex gap-4 py-2 border-b border-zinc-900/40 hover:bg-zinc-900/10 rounded transition min-h-[64px]" id={`calendar-hour-${hour}`}>
                  {/* Time indicator */}
                  <div className="w-20 text-right shrink-0 select-none">
                    <span className="text-xs font-mono font-bold text-zinc-500">{formatHour(hour)}</span>
                  </div>

                  {/* Events slots wrapper */}
                  <div className="flex-1 flex flex-col gap-1.5">
                    {hourEvents.length === 0 ? (
                      <div className="h-full flex items-center pl-2 text-[11px] text-zinc-600 italic">
                        Empty time slot
                      </div>
                    ) : (
                      hourEvents.map(e => {
                        const associatedTask = getTaskForEvent(e.id);
                        const isLocked = e.isLocked;

                        return (
                          <div
                            key={e.id}
                            onClick={() => setSelectedSlot(selectedSlot === e.id ? null : e.id)}
                            className={`p-2.5 rounded-xl border text-xs cursor-pointer flex items-center justify-between transition-all duration-200 hover:-translate-y-0.5 ${
                              isLocked
                                ? 'bg-zinc-900/80 border-zinc-800 text-zinc-300'
                                : associatedTask?.panicLevel === 'panic'
                                  ? 'bg-rose-950/60 border-red-800 text-rose-200'
                                  : 'bg-amber-950/40 border-amber-800 text-amber-200'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              {isLocked ? (
                                <Lock className="w-3.5 h-3.5 text-zinc-400" />
                              ) : (
                                <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                              )}
                              <div className="truncate">
                                <span className="font-bold">{e.title}</span>
                                {associatedTask && (
                                  <span className={`ml-2 px-1.5 py-0.5 rounded text-[8px] uppercase ${
                                    associatedTask.status === 'completed' ? 'bg-emerald-950 text-emerald-400' : 'bg-zinc-900 text-zinc-400'
                                  }`}>
                                    {associatedTask.status}
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Drop action menu inside slot */}
                            {selectedSlot === e.id && !isLocked && (
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onClearAIEvent(e.currentTarget.id);
                                  }}
                                  id={e.id}
                                  className="p-1 rounded bg-zinc-950/80 hover:bg-red-950/60 text-zinc-400 hover:text-red-400 border border-zinc-800 transition"
                                  title="Remove slot"
                                >
                                  <Trash className="w-3 h-3" />
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sidebar Schedule Recommendations */}
        <div className="flex flex-col gap-4">
          <div className="border border-zinc-800 rounded-2xl bg-zinc-950/20 p-4 flex flex-col gap-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" />
              Scheduling Insights
            </h3>

            <div className="text-xs text-zinc-400 leading-relaxed flex flex-col gap-2.5">
              <p>
                Our AI analyzes deadline urgency, task duration estimates, and calendar load to map optimal focus periods.
              </p>
              <div className="p-3 bg-zinc-900/40 rounded-xl border border-zinc-800 flex gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <p className="text-[11px]">
                  <strong>Focus buffers</strong> are dynamically configured to separate consecutive sessions, reducing mental fatigue and avoiding deadline panics.
                </p>
              </div>
            </div>
          </div>

          {/* Quick task status indicator list */}
          <div className="border border-zinc-800 rounded-2xl bg-zinc-950/20 p-4 flex flex-col gap-3">
            <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Unscheduled Priorities</h3>
            <div className="flex flex-col gap-2 max-h-[220px] overflow-y-auto">
              {tasks.filter(t => t.status !== 'completed' && !events.some(e => e.associatedTaskId === t.id)).length === 0 ? (
                <p className="text-xs text-zinc-500 italic">All active tasks scheduled!</p>
              ) : (
                tasks.filter(t => t.status !== 'completed' && !events.some(e => e.associatedTaskId === t.id)).map(task => (
                  <div key={task.id} className="p-2 rounded-lg bg-zinc-900/30 border border-zinc-800/40 flex items-center justify-between text-xs">
                    <span className="font-semibold text-zinc-200 truncate max-w-[150px]">{task.title}</span>
                    <span className="text-[10px] text-zinc-400 font-mono">⏱️ {task.estimatedDuration}m</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
