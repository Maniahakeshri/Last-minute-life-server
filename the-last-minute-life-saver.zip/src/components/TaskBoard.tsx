import React, { useState } from 'react';
import { 
  Plus, Calendar, ShieldAlert, Sparkles, AlertTriangle, CheckSquare, 
  Square, CheckCircle, Clock, Trash2, ListTodo, Sliders, ChevronDown, ChevronUp, Loader2
} from 'lucide-react';
import { Task, SubTask } from '../types';

interface TaskBoardProps {
  tasks: Task[];
  onAddTask: (task: Omit<Task, 'id' | 'aiPrioritizationScore' | 'panicLevel'>) => void;
  onUpdateTask: (task: Task) => void;
  onDeleteTask: (id: string) => void;
  onPrioritizeWithAI: () => Promise<void>;
  isPrioritizing: boolean;
}

export default function TaskBoard({
  tasks,
  onAddTask,
  onUpdateTask,
  onDeleteTask,
  onPrioritizeWithAI,
  isPrioritizing,
}: TaskBoardProps) {
  const [showForm, setShowForm] = useState(false);
  const [expandedTask, setExpandedTask] = useState<string | null>(null);
  const [isBreakingDown, setIsBreakingDown] = useState<string | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [priority, setPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [estimatedDuration, setEstimatedDuration] = useState(60); // minutes
  const [category, setCategory] = useState('Study');
  const [bufferMinutes, setBufferMinutes] = useState(15);

  const categories = ['Work', 'Study', 'Bills', 'Personal', 'Other'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !deadline) return;

    onAddTask({
      title,
      description,
      deadline: new Date(deadline).toISOString(),
      priority,
      estimatedDuration: Number(estimatedDuration),
      status: 'todo',
      category,
      bufferMinutes: Number(bufferMinutes),
      subtasks: [],
      scheduledStart: null,
    });

    // Reset Form
    setTitle('');
    setDescription('');
    setDeadline('');
    setPriority('medium');
    setEstimatedDuration(60);
    setCategory('Study');
    setBufferMinutes(15);
    setShowForm(false);
  };

  const toggleExpand = (id: string) => {
    setExpandedTask(expandedTask === id ? null : id);
  };

  const handleStatusChange = (task: Task, newStatus: Task['status']) => {
    onUpdateTask({ ...task, status: newStatus });
  };

  const handleSubtaskToggle = (task: Task, subtaskId: string) => {
    const updatedSubtasks = task.subtasks.map(st => 
      st.id === subtaskId ? { ...st, completed: !st.completed } : st
    );
    
    // Check if all subtasks are completed, maybe prompt status upgrade
    const allCompleted = updatedSubtasks.every(st => st.completed);
    let newStatus = task.status;
    if (allCompleted && task.status === 'todo') {
      newStatus = 'in_progress';
    }

    onUpdateTask({
      ...task,
      subtasks: updatedSubtasks,
      status: newStatus,
    });
  };

  const handleAddSubtask = (task: Task, subtaskTitle: string) => {
    if (!subtaskTitle.trim()) return;
    const newSub: SubTask = {
      id: `sub-manual-${Date.now()}`,
      title: subtaskTitle,
      completed: false,
    };
    onUpdateTask({
      ...task,
      subtasks: [...task.subtasks, newSub],
    });
  };

  // Trigger Gemini autonomous task breakdown
  const triggerBreakdown = async (task: Task) => {
    try {
      setIsBreakingDown(task.id);
      const response = await fetch('/api/ai/breakdown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: task.title,
          description: task.description,
          category: task.category,
        }),
      });

      if (!response.ok) throw new Error('Failed to fetch breakdown from server.');
      const data = await response.json();
      
      onUpdateTask({
        ...task,
        subtasks: [...task.subtasks, ...(data.subtasks || [])],
      });
    } catch (err) {
      console.error(err);
    } finally {
      setIsBreakingDown(null);
    }
  };

  // Helper colors for urgency & categories
  const getPriorityBadge = (p: Task['priority']) => {
    switch (p) {
      case 'high': return 'bg-red-500/10 text-red-400 border-red-500/20';
      case 'medium': return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'low': return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20';
    }
  };

  const getPanicBadge = (p: Task['panicLevel']) => {
    switch (p) {
      case 'panic': return 'bg-rose-950 text-red-400 border-red-500 animate-pulse font-bold';
      case 'warning': return 'bg-amber-950 text-amber-400 border-amber-500';
      case 'calm': return 'bg-zinc-900 text-zinc-400 border-zinc-800';
    }
  };

  // Calculate task completion percentage
  const getProgress = (task: Task) => {
    if (task.subtasks.length === 0) return task.status === 'completed' ? 100 : 0;
    const completedCount = task.subtasks.filter(st => st.completed).length;
    return Math.round((completedCount / task.subtasks.length) * 100);
  };

  // Sort tasks by custom score or due date
  const sortedTasks = [...tasks].sort((a, b) => {
    if (a.status === 'completed' && b.status !== 'completed') return 1;
    if (a.status !== 'completed' && b.status === 'completed') return -1;
    // Sort high AI priority score first
    return b.aiPrioritizationScore - a.aiPrioritizationScore;
  });

  return (
    <div className="flex flex-col gap-6" id="task-board-module">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ListTodo className="w-5 h-5 text-amber-500" />
            Task Control Center
          </h2>
          <p className="text-xs text-zinc-400">Order by AI Urgency Index. Add buffer cushion dynamically.</p>
        </div>
        
        <div className="flex items-center gap-2">
          {/* AI Prioritize button */}
          <button
            onClick={onPrioritizeWithAI}
            disabled={isPrioritizing || tasks.length === 0}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-600 to-red-600 hover:from-amber-500 hover:to-red-500 disabled:from-zinc-800 disabled:to-zinc-800 disabled:text-zinc-500 text-white font-semibold rounded-xl text-xs transition duration-200 cursor-pointer shadow-md"
            id="ai-prioritize-btn"
          >
            {isPrioritizing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Recalculating...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                AI Prioritizer
              </>
            )}
          </button>

          {/* Add task button */}
          <button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-1.5 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white font-semibold rounded-xl text-xs transition cursor-pointer"
            id="toggle-task-form-btn"
          >
            <Plus className="w-4 h-4" />
            New Task
          </button>
        </div>
      </div>

      {/* Task Creation Form Drawer */}
      {showForm && (
        <form onSubmit={handleSubmit} className="p-5 rounded-2xl border border-zinc-800 bg-zinc-900/60 flex flex-col gap-4 animate-fadeIn" id="create-task-form">
          <h3 className="text-sm font-bold text-white">Create Urgency-Managed Task</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-zinc-300">Task Title *</label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="CSC 411 Assignment 3, Pay Rent, Prep slide..."
                className="px-3.5 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-zinc-300">Category</label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  className="px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-zinc-300">Priority</label>
                <select
                  value={priority}
                  onChange={e => setPriority(e.target.value as any)}
                  className="px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="high">High (Red)</option>
                  <option value="medium">Medium (Amber)</option>
                  <option value="low">Low (Blue)</option>
                </select>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-zinc-400" />
                Deadline Time *
              </label>
              <input
                type="datetime-local"
                required
                value={deadline}
                onChange={e => setDeadline(e.target.value)}
                className="px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-zinc-300">Est. Duration (Minutes)</label>
              <input
                type="number"
                min="5"
                max="1440"
                value={estimatedDuration}
                onChange={e => setEstimatedDuration(Number(e.target.value))}
                className="px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-zinc-300 flex items-center justify-between">
                <span>Buffer Cushion (Mins)</span>
                <span className="text-[10px] text-amber-500 font-mono font-bold">+{bufferMinutes}m</span>
              </label>
              <input
                type="range"
                min="0"
                max="120"
                step="5"
                value={bufferMinutes}
                onChange={e => setBufferMinutes(Number(e.target.value))}
                className="accent-amber-500 bg-zinc-950 border border-zinc-800 rounded-lg cursor-pointer py-1"
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-zinc-300">Description / Specific Details</label>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="What are the key grading elements, submission URLs, or contacts?"
              rows={2}
              className="px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500 resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 mt-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-4 py-1.5 rounded-lg text-zinc-400 hover:text-white text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs transition"
            >
              Enlist Task
            </button>
          </div>
        </form>
      )}

      {/* Task Cards Grid */}
      <div className="flex flex-col gap-3">
        {sortedTasks.length === 0 ? (
          <div className="p-8 text-center border border-dashed border-zinc-800 rounded-2xl bg-zinc-950/20">
            <p className="text-zinc-500 text-sm">No tasks tracked yet. Add one to defend against your deadlines!</p>
          </div>
        ) : (
          sortedTasks.map(task => {
            const isExpanded = expandedTask === task.id;
            const progress = getProgress(task);
            
            // Format dynamic display deadline label
            const deadlineDate = new Date(task.deadline);
            const formattedDate = deadlineDate.toLocaleDateString(undefined, { 
              month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' 
            });

            return (
              <div 
                key={task.id} 
                className={`group border rounded-2xl bg-zinc-950/40 hover:bg-zinc-900/40 transition-all duration-300 flex flex-col overflow-hidden ${
                  task.status === 'completed' 
                    ? 'border-zinc-900 opacity-60' 
                    : task.panicLevel === 'panic'
                      ? 'border-red-500/30 shadow-md shadow-red-950/20'
                      : task.panicLevel === 'warning'
                        ? 'border-amber-500/30'
                        : 'border-zinc-800'
                }`}
                id={`task-item-${task.id}`}
              >
                {/* Master Card Header */}
                <div className="p-4 flex items-center justify-between gap-4 cursor-pointer" onClick={() => toggleExpand(task.id)}>
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    {/* Status Checkbox */}
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleStatusChange(task, task.status === 'completed' ? 'todo' : 'completed');
                      }}
                      className="text-zinc-500 hover:text-white transition shrink-0"
                    >
                      {task.status === 'completed' ? (
                        <CheckCircle className="w-5 h-5 text-emerald-500" />
                      ) : (
                        <div className="w-5 h-5 rounded-md border-2 border-zinc-600 hover:border-amber-500 flex items-center justify-center" />
                      )}
                    </button>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        {/* Title */}
                        <h4 className={`text-sm font-semibold truncate text-white ${task.status === 'completed' ? 'line-through text-zinc-500' : ''}`}>
                          {task.title}
                        </h4>
                        
                        {/* Category badge */}
                        <span className="px-2 py-0.5 rounded-full bg-zinc-900 text-zinc-400 border border-zinc-800 text-[9px] font-medium uppercase font-mono">
                          {task.category}
                        </span>

                        {/* AI Score Badge */}
                        {task.aiPrioritizationScore > 0 && (
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold border flex items-center gap-0.5 ${
                            task.aiPrioritizationScore >= 85 
                              ? 'bg-red-950 text-red-400 border-red-800' 
                              : 'bg-amber-950/80 text-amber-400 border-amber-800'
                          }`}>
                            <Sparkles className="w-2.5 h-2.5" />
                            AI URGENCY: {task.aiPrioritizationScore}%
                          </span>
                        )}
                      </div>

                      {/* Description snippet */}
                      <p className="text-xs text-zinc-400 truncate max-w-md">
                        {task.description || 'No description provided.'}
                      </p>
                    </div>
                  </div>

                  {/* Timing & Badges */}
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right hidden sm:block">
                      <div className="text-xs font-semibold text-zinc-300 flex items-center gap-1 justify-end">
                        <Clock className="w-3.5 h-3.5 text-zinc-500" />
                        {formattedDate}
                      </div>
                      <div className="text-[10px] text-zinc-500 mt-0.5">
                        Est: {task.estimatedDuration}m (+{task.bufferMinutes}m cushion)
                      </div>
                    </div>

                    <span className={`px-2 py-1 rounded-lg border text-[10px] uppercase font-mono tracking-wider ${getPanicBadge(task.panicLevel)}`}>
                      {task.panicLevel === 'panic' ? 'PANIC' : task.panicLevel === 'warning' ? 'WARNING' : 'STABLE'}
                    </span>

                    <button className="text-zinc-500 hover:text-white transition">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Subtask Progress bar */}
                {task.subtasks.length > 0 && (
                  <div className="h-1 bg-zinc-900 w-full">
                    <div 
                      className={`h-full transition-all duration-300 ${
                        task.status === 'completed' ? 'bg-emerald-600' : 'bg-amber-500'
                      }`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                )}

                {/* Expanded Details Panel */}
                {isExpanded && (
                  <div className="p-4 bg-zinc-900/30 border-t border-zinc-900 flex flex-col gap-4 animate-slideDown">
                    {/* Full Description */}
                    {task.description && (
                      <div className="text-xs text-zinc-300 leading-relaxed bg-zinc-950/40 p-3 rounded-lg border border-zinc-800">
                        <strong>Mission Briefing:</strong>
                        <p className="mt-1">{task.description}</p>
                      </div>
                    )}

                    {/* AI Smart Recommendation Callout */}
                    {task.aiActionRecommendation && (
                      <div className="p-3 rounded-lg bg-amber-950/20 border border-amber-500/20 flex gap-2.5 items-start">
                        <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <div className="text-xs">
                          <span className="text-amber-300 font-bold">AI Strategic Advice:</span>
                          <p className="text-zinc-300 mt-0.5 leading-relaxed">{task.aiActionRecommendation}</p>
                        </div>
                      </div>
                    )}

                    {/* Subtask Autonomous Checklist */}
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-zinc-200">Execution Plan Checklist</span>
                        
                        {/* Gemini autonomous breakdown trigger */}
                        <button
                          onClick={() => triggerBreakdown(task)}
                          disabled={isBreakingDown !== null}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-[10px] font-semibold text-amber-400 hover:text-amber-300 transition disabled:opacity-40"
                        >
                          {isBreakingDown === task.id ? (
                            <>
                              <Loader2 className="w-3 h-3 animate-spin" />
                              Generating Plan...
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3 h-3" />
                              Autonomous AI Plan Breakdown
                            </>
                          )}
                        </button>
                      </div>

                      <div className="flex flex-col gap-1.5 bg-zinc-950/30 p-3 rounded-xl border border-zinc-900">
                        {task.subtasks.length === 0 ? (
                          <p className="text-[11px] text-zinc-500 italic">No checklist items. Generate a step-by-step roadmap with AI above to overcome procrastination!</p>
                        ) : (
                          task.subtasks.map(st => (
                            <div 
                              key={st.id} 
                              className="flex items-center justify-between text-xs py-1 hover:bg-zinc-900/40 px-1 rounded transition"
                            >
                              <label className="flex items-center gap-2.5 text-zinc-300 cursor-pointer flex-1 min-w-0">
                                <input
                                  type="checkbox"
                                  checked={st.completed}
                                  onChange={() => handleSubtaskToggle(task, st.id)}
                                  className="accent-amber-500 rounded text-amber-600 bg-zinc-900 border-zinc-700 focus:ring-amber-500"
                                />
                                <span className={`truncate ${st.completed ? 'line-through text-zinc-500' : ''}`}>
                                  {st.title}
                                </span>
                              </label>

                              {st.estimatedMinutes && (
                                <span className="text-[10px] font-mono text-zinc-500 font-semibold shrink-0">
                                  ⏱️ {st.estimatedMinutes}m
                                </span>
                              )}
                            </div>
                          ))
                        )}

                        {/* Manual Subtask Addition */}
                        <input
                          type="text"
                          placeholder="Add custom step..."
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              handleAddSubtask(task, e.currentTarget.value);
                              e.currentTarget.value = '';
                            }
                          }}
                          className="mt-2 text-xs bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 focus:outline-none focus:border-amber-500 text-white"
                        />
                      </div>
                    </div>

                    {/* Footer operations */}
                    <div className="flex items-center justify-between pt-2 border-t border-zinc-900">
                      <div className="flex items-center gap-2 text-xs text-zinc-400">
                        <span>Status: </span>
                        <select
                          value={task.status}
                          onChange={e => handleStatusChange(task, e.target.value as any)}
                          className="bg-zinc-950 text-xs border border-zinc-800 rounded px-2 py-0.5 text-white"
                        >
                          <option value="todo">To Do</option>
                          <option value="in_progress">In Progress</option>
                          <option value="completed">Completed</option>
                          <option value="missed">Missed</option>
                        </select>
                      </div>

                      <button
                        onClick={() => onDeleteTask(task.id)}
                        className="p-1.5 rounded bg-zinc-900 hover:bg-red-950 text-zinc-400 hover:text-red-400 border border-zinc-800 hover:border-red-900 transition flex items-center gap-1 text-[10px]"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Delete Task
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
