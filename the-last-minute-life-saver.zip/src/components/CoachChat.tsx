import { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, Mic, MicOff, Volume2, VolumeX, ShieldAlert, Zap, Compass, User, RefreshCw, HelpCircle } from 'lucide-react';
import { ChatMessage, DBState } from '../types';

interface CoachChatProps {
  dbState: DBState;
  messages: ChatMessage[];
  onSendMessage: (text: string) => Promise<void>;
  onResetChat: () => void;
  isChatLoading: boolean;
}

export default function CoachChat({
  dbState,
  messages,
  onSendMessage,
  onResetChat,
  isChatLoading,
}: CoachChatProps) {
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [readAloudEnabled, setReadAloudEnabled] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  
  // Browser speech engines
  const recognitionRef = useRef<any>(null);
  const speechUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle native Speech Recognition (Voice Input)
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'en-US';

      rec.onstart = () => {
        setIsRecording(true);
      };

      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(prev => (prev ? prev + ' ' + transcript : transcript));
      };

      rec.onerror = (e: any) => {
        console.error('Speech recognition error', e);
        setIsRecording(false);
      };

      rec.onend = () => {
        setIsRecording(false);
      };

      recognitionRef.current = rec;
    }
  }, []);

  const toggleRecording = () => {
    if (!recognitionRef.current) {
      alert('Speech Recognition is not supported or permitted in this browser.');
      return;
    }

    if (isRecording) {
      recognitionRef.current.stop();
    } else {
      // Cancel speech output first if playing
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      recognitionRef.current.start();
    }
  };

  const handleSend = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || isChatLoading) return;

    if (!textToSend) setInputText('');
    
    // Stop speaking currently reading voice
    window.speechSynthesis.cancel();
    setIsSpeaking(false);

    await onSendMessage(text);
  };

  // Text-To-Speech reader
  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    
    // Cancel existing
    window.speechSynthesis.cancel();

    if (isSpeaking) {
      setIsSpeaking(false);
      return;
    }

    // Strip out markdown bold/symbols for clean pronunciation
    const cleanText = text
      .replace(/[*_#`~]/g, '')
      .replace(/🚨|⚡|⚠️|📅/g, '')
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    
    // Attempt to pick a smooth, calming female/counselor voice if available
    const voices = window.speechSynthesis.getVoices();
    const premiumVoice = voices.find(v => v.name.includes('Google US English') || v.name.includes('Samantha') || v.name.includes('Natural'));
    if (premiumVoice) utterance.voice = premiumVoice;

    utterance.onend = () => {
      setIsSpeaking(false);
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
    };

    speechUtteranceRef.current = utterance;
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  // Auto-speak new assistant message if enabled
  useEffect(() => {
    if (readAloudEnabled && messages.length > 0) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg.role === 'assistant') {
        speakText(lastMsg.content);
      }
    }
  }, [messages, readAloudEnabled]);

  // Clean speaking on unmount
  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
    };
  }, []);

  // Quick SOS Prompts
  const sosTemplates = [
    {
      title: '🚨 I am panicking right now!',
      text: 'I am panicking right now. I have critical deadlines and I am completely overwhelmed. Please help me calm down and figure out what to do.'
    },
    {
      title: '⚡ Give me a 5-minute win',
      text: 'Give me a 5-minute microscopic win to break procrastination on my list. What is the easiest thing I can clear off right now?'
    },
    {
      title: '📅 Auto-adjust my chaotic day',
      text: 'Explain how my calendar schedule blocks align with my stress priority. Give me an executive coaching summary of today\'s battle plan.'
    }
  ];

  return (
    <div className="border border-zinc-800 rounded-2xl bg-zinc-950/40 p-4 flex flex-col h-[520px] justify-between overflow-hidden" id="coach-chat-widget">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-amber-600/20 text-amber-500">
            <Sparkles className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">Urgency Counselor</h3>
            <p className="text-[10px] text-zinc-500">AI stress interventionist & audio guide</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setReadAloudEnabled(!readAloudEnabled)}
            className={`p-1.5 rounded-lg border text-xs transition ${
              readAloudEnabled 
                ? 'bg-amber-950/40 text-amber-500 border-amber-800' 
                : 'bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white'
            }`}
            title={readAloudEnabled ? 'Auto Speak is enabled' : 'Auto Speak is disabled'}
          >
            {readAloudEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={onResetChat}
            className="p-1.5 rounded-lg border border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:text-white text-xs transition"
            title="Reset Conversation"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Messages viewport */}
      <div className="flex-1 overflow-y-auto py-3 px-1 flex flex-col gap-3 max-h-[340px]">
        {messages.length === 0 ? (
          <div className="flex flex-col gap-3 my-auto items-center text-center p-4">
            <Compass className="w-8 h-8 text-zinc-600 animate-spin-slow" />
            <div className="flex flex-col gap-1">
              <p className="text-xs font-semibold text-zinc-300">Choose an SOS Lifeline:</p>
              <p className="text-[10px] text-zinc-500 max-w-[200px]">Click a fast template or type a message below.</p>
            </div>

            <div className="flex flex-col gap-1.5 w-full mt-2">
              {sosTemplates.map((tpl, i) => (
                <button
                  key={i}
                  onClick={() => handleSend(tpl.text)}
                  className="p-2.5 rounded-xl border border-zinc-900 bg-zinc-900/40 hover:bg-zinc-900/80 text-[11px] text-left text-zinc-300 hover:text-white transition duration-200 cursor-pointer"
                >
                  {tpl.title}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map(m => {
            const isUser = m.role === 'user';
            return (
              <div
                key={m.id}
                className={`flex flex-col gap-1 max-w-[85%] ${
                  isUser ? 'ml-auto items-end' : 'mr-auto items-start'
                }`}
              >
                <div className="flex items-center gap-1.5 text-[10px] text-zinc-500 font-mono">
                  {isUser ? (
                    <>
                      <span>You</span>
                      <User className="w-2.5 h-2.5" />
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-2.5 h-2.5 text-amber-500" />
                      <span>Calming Coach</span>
                    </>
                  )}
                </div>

                <div className={`p-3 rounded-2xl text-xs leading-relaxed border ${
                  isUser
                    ? 'bg-zinc-900 border-zinc-800 text-zinc-200 rounded-tr-none'
                    : 'bg-amber-950/20 border-amber-900/40 text-zinc-300 rounded-tl-none font-medium'
                }`}>
                  <p className="whitespace-pre-line">{m.content}</p>

                  {/* Play audio button on assistant message */}
                  {!isUser && (
                    <div className="flex justify-end mt-2 pt-1 border-t border-amber-950/20">
                      <button
                        onClick={() => speakText(m.content)}
                        className={`p-1 rounded text-[10px] flex items-center gap-1 hover:bg-amber-950/60 transition ${
                          isSpeaking ? 'text-red-400 font-bold' : 'text-amber-500 font-semibold'
                        }`}
                      >
                        <Volume2 className="w-3 h-3" />
                        {isSpeaking ? 'Stop speaking' : 'Speak counselor voice'}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Input panel with Voice recognition support */}
      <div className="flex items-center gap-2 border-t border-zinc-900 pt-3">
        {/* Record Microphone Voice input button */}
        <button
          onClick={toggleRecording}
          className={`p-2 rounded-xl border transition cursor-pointer shrink-0 ${
            isRecording
              ? 'bg-red-950 text-red-500 border-red-800 animate-pulse'
              : 'bg-zinc-900/60 text-zinc-400 border-zinc-800 hover:text-white'
          }`}
          title={isRecording ? 'Listening... Speak now.' : 'Voice input'}
        >
          {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </button>

        <input
          type="text"
          value={inputText}
          onChange={e => setInputText(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') handleSend();
          }}
          disabled={isChatLoading}
          placeholder={isRecording ? 'Listening to voice...' : 'Ask counselor, type command...'}
          className="flex-1 bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 disabled:opacity-40"
        />

        <button
          onClick={() => handleSend()}
          disabled={isChatLoading || !inputText.trim()}
          className="p-2 bg-amber-600 hover:bg-amber-500 disabled:bg-zinc-800 disabled:text-zinc-500 text-white rounded-xl transition cursor-pointer shrink-0"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
