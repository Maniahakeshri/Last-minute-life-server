import React, { useState } from 'react';
import { Sparkles, Flame, Check, Plus, Trash2 } from 'lucide-react';
import { Habit } from '../types';

interface HabitBoardProps {
  habits: Habit[];
  onAddHabit: (title: string, frequency: 'daily' | 'weekly') => void;
  onToggleHabit: (id: string) => void;
  onDeleteHabit: (id: string) => void;
}

export default function HabitBoard({
  habits,
  onAddHabit,
  onToggleHabit,
  onDeleteHabit,
}: HabitBoardProps) {
  const [newTitle, setNewTitle] = useState('');
  const [frequency, setFrequency] = useState<'daily' | 'weekly'>('daily');
  const [showAdd, setShowAdd] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onAddHabit(newTitle.trim(), frequency);
    setNewTitle('');
    setShowAdd(false);
  };

  const isCompletedToday = (habit: Habit) => {
    if (!habit.lastCompleted) return false;
    const todayStr = new Date().toISOString().split('T')[0];
    return habit.lastCompleted === todayStr;
  };

  return (
    <div className="border border-zinc-800 rounded-2xl bg-zinc-950/40 p-4 flex flex-col gap-4" id="habit-board-module">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
          <Flame className="w-4 h-4 text-orange-500 animate-pulse" />
          Anti-Procrastination Streaks
        </h3>
        
        <button
          onClick={() => setShowAdd(!showAdd)}
          className="text-xs text-amber-500 hover:text-amber-400 font-semibold cursor-pointer"
        >
          {showAdd ? 'Cancel' : '+ New Habit'}
        </button>
      </div>

      {showAdd && (
        <form onSubmit={handleSubmit} className="flex flex-col gap-2 p-3 bg-zinc-900/60 rounded-xl border border-zinc-800 animate-fadeIn">
          <input
            type="text"
            required
            value={newTitle}
            onChange={e => setNewTitle(e.target.value)}
            placeholder="Review Cal/Deadlines, 15m focus..."
            className="px-2.5 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-xs text-white focus:outline-none focus:border-amber-500"
          />
          <div className="flex items-center justify-between gap-2 mt-1">
            <select
              value={frequency}
              onChange={e => setFrequency(e.target.value as any)}
              className="bg-zinc-950 text-[10px] border border-zinc-800 rounded px-2 py-1 text-white"
            >
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
            </select>
            <button
              type="submit"
              className="px-3 py-1 rounded bg-amber-600 hover:bg-amber-500 text-[10px] font-bold text-white"
            >
              Add Habit
            </button>
          </div>
        </form>
      )}

      <div className="flex flex-col gap-2.5">
        {habits.length === 0 ? (
          <p className="text-[11px] text-zinc-500 italic text-center py-2">No habits tracked yet.</p>
        ) : (
          habits.map(h => {
            const completed = isCompletedToday(h);
            return (
              <div
                key={h.id}
                className="flex items-center justify-between p-3 rounded-xl border border-zinc-900 bg-zinc-900/10 hover:bg-zinc-900/20 transition-all duration-200"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <button
                    onClick={() => onToggleHabit(h.id)}
                    className={`w-6 h-6 rounded-lg flex items-center justify-center transition border ${
                      completed
                        ? 'bg-emerald-600 border-emerald-500 text-white'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-500 hover:border-amber-500'
                    }`}
                  >
                    {completed ? <Check className="w-3.5 h-3.5" /> : null}
                  </button>

                  <div className="min-w-0">
                    <div className={`text-xs font-semibold truncate ${completed ? 'line-through text-zinc-500' : 'text-white'}`}>
                      {h.title}
                    </div>
                    <div className="text-[9px] text-zinc-500 mt-0.5 capitalize">
                      {h.frequency}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  {/* Streak widget */}
                  <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-orange-950/40 border border-orange-900 text-orange-400 font-mono text-[10px] font-bold">
                    <Flame className="w-3.5 h-3.5 text-orange-500" />
                    <span>{h.streak}d</span>
                  </div>

                  <button
                    onClick={() => onDeleteHabit(h.id)}
                    className="p-1 rounded text-zinc-600 hover:text-red-400 hover:bg-zinc-950 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
