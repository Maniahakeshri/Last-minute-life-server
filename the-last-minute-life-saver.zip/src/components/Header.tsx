import { useState, useEffect } from 'react';
import { ShieldAlert, Zap, Clock, Smile, AlertTriangle } from 'lucide-react';
import { Task } from '../types';

interface HeaderProps {
  tasks: Task[];
  settings: {
    panicThresholdHours: number;
  };
}

export default function Header({ tasks, settings }: HeaderProps) {
  const [time, setTime] = useState<Date>(new Date());
  const [nearestTask, setNearestTask] = useState<Task | null>(null);
  const [countdownStr, setCountdownStr] = useState<string>('No upcoming deadlines');

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const incomplete = tasks.filter(t => t.status !== 'completed' && t.status !== 'missed');
    if (incomplete.length === 0) {
      setNearestTask(null);
      setCountdownStr('No upcoming deadlines');
      return;
    }

    // Sort by deadline ascending
    const sorted = [...incomplete].sort(
      (a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime()
    );
    const nearest = sorted[0];
    setNearestTask(nearest);

    const deadlineTime = new Date(nearest.deadline).getTime();
    const diff = deadlineTime - time.getTime();

    if (diff <= 0) {
      setCountdownStr('Deadline reached!');
    } else {
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const secs = Math.floor((diff % (1000 * 60)) / 1000);
      setCountdownStr(`${hours}h ${mins}m ${secs}s left`);
    }
  }, [tasks, time]);

  // Calculate stress level index (0-100) based on incomplete high-priority tasks and nearest deadlines
  const calculateStressIndex = () => {
    const incomplete = tasks.filter(t => t.status !== 'completed');
    if (incomplete.length === 0) return 0;

    let totalWeight = 0;
    incomplete.forEach(t => {
      let weight = 10; // Base weight
      if (t.priority === 'high') weight += 20;
      if (t.priority === 'medium') weight += 10;

      // Deadline proximity multiplier
      const timeRemainingMs = new Date(t.deadline).getTime() - Date.now();
      const hrsRemaining = timeRemainingMs / (1000 * 60 * 60);

      if (hrsRemaining > 0) {
        if (hrsRemaining < 6) weight += 50;
        else if (hrsRemaining < 12) weight += 35;
        else if (hrsRemaining < 24) weight += 20;
        else if (hrsRemaining < 48) weight += 10;
      } else {
        weight += 40; // Overdue task stress
      }
      totalWeight += weight;
    });

    const averageStress = totalWeight / incomplete.length;
    return Math.min(100, Math.round(averageStress * 1.5));
  };

  const stressIndex = calculateStressIndex();

  const getStressColor = (index: number) => {
    if (index >= 75) return 'text-red-500 bg-red-950/40 border-red-800';
    if (index >= 40) return 'text-amber-500 bg-amber-950/40 border-amber-800';
    return 'text-emerald-500 bg-emerald-950/40 border-emerald-800';
  };

  const getStressIcon = (index: number) => {
    if (index >= 75) return <ShieldAlert className="w-6 h-6 animate-pulse" />;
    if (index >= 40) return <AlertTriangle className="w-6 h-6 text-amber-500 animate-bounce" />;
    return <Smile className="w-6 h-6 text-emerald-500" />;
  };

  const getStressLabel = (index: number) => {
    if (index >= 75) return 'CRITICAL PANIC';
    if (index >= 40) return 'MODERATE URGENCY';
    return 'STABLE CLARITY';
  };

  return (
    <header className="p-6 border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6" id="app-header-container">
        {/* Logo and Name */}
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-to-tr from-amber-600 to-red-600 shadow-md animate-pulse">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
              The Last-Minute Life Saver
            </h1>
            <p className="text-xs text-zinc-400">Your AI Proactive Defense Against Looming Deadlines</p>
          </div>
        </div>

        {/* Dynamic Countdown bar & Panic Metrics */}
        <div className="flex flex-wrap items-center gap-4 w-full md:w-auto justify-end">
          {/* Stress Index widget */}
          <div className={`flex items-center gap-3 px-4 py-3 rounded-xl border ${getStressColor(stressIndex)} transition-colors duration-300`}>
            {getStressIcon(stressIndex)}
            <div>
              <div className="text-[10px] font-mono tracking-wider uppercase opacity-85">Stress Index</div>
              <div className="text-sm font-extrabold flex items-baseline gap-1.5">
                <span>{stressIndex}%</span>
                <span className="text-[10px] font-medium opacity-80">• {getStressLabel(stressIndex)}</span>
              </div>
            </div>
          </div>

          {/* Time & Countdown Widget */}
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl border border-zinc-800 bg-zinc-900/60 text-white min-w-[240px]">
            <Clock className="w-5 h-5 text-amber-400 animate-spin-slow" />
            <div className="w-full">
              <div className="text-[10px] font-mono uppercase tracking-wider text-zinc-400 flex justify-between">
                <span>Nearest Deadline</span>
                {nearestTask && (
                  <span className="truncate max-w-[100px] text-amber-400 font-semibold">{nearestTask.title}</span>
                )}
              </div>
              <div className="text-sm font-extrabold tracking-tight font-mono text-amber-300">
                {countdownStr}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Extreme Panic Warning Banner if stress > 75% */}
      {stressIndex >= 75 && (
        <div className="mt-4 p-3 rounded-lg bg-red-950/60 border border-red-500/30 text-red-400 text-xs flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
            <span>
              <strong>Emergency Mode Active:</strong> You have critical high-priority items due within {settings.panicThresholdHours} hours. Turn off notifications and use the **AI Counseling Coach** SOS button!
            </span>
          </div>
        </div>
      )}
    </header>
  );
}
